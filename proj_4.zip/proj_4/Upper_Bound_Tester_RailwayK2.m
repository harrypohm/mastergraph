
clear;
close all;
clc;

k2_record_txt = '.\fuqh_test2\record\result2.txt';
[py_t,qr_t] = textread(k2_record_txt,'%n%n'); %#ok<*DTXTRD>

K = 2;                          % k-Connectivity
bound_d = 12;                   % Bounded Degree
num_of_graph = length(qr_t);    % Number of Testing Instances
epsilon_clique = 2 / (bound_d^2);
                                % Recommended Epsilon for Cli-Con Grraphs
accept_pro = 0.67;              % Probability to Accept/Reject ...
                                % when Epsilon-Far-From k-Connected
N = 3000;                       % Number of Graph Vertices

eps_list = zeros(num_of_graph, 1);
for i = 1 : num_of_graph
eps_list(i) = ((i - num_of_graph / 2) * ...
    (0.5 / (num_of_graph / 2)) + 1) * epsilon_clique;
end
    
magn_qr_t = eps_list;
% log(1 ./ (eps_list * bound_d)) ./ (eps_list * bound_d);

figure(1);

semilogy(magn_qr_t, qr_t, '.');
hold on;
%{
plot(magn_qr_t, y_cal01, '--');

alpha = 0.05;
AugMAG = [ones(length(magn_qr_t),1) magn_qr_t];
[b_new, bint, r_new, rint, stats] = regress(qr_t, AugMAG, alpha);
% b_new = AugMAG \ qr_t;

y_cal02 = AugMAG * b_new;
plot(magn_qr_t, y_cal02, 'r-');
%}

const = - 16 * K * log(1 - accept_pro) * log2(bound_d) * bound_d ^ (2 - 2/K);     % Constant Term of Complexity

%% t-test for unknown variance
y_cal03 = const * log2(8 ./ eps_list) ./ eps_list;
y_cal03_mean = y_cal03 ./ 2;
semilogy(magn_qr_t, y_cal03);
semilogy(magn_qr_t, y_cal03_mean);
axis tight
miu_norm = (max(y_cal03) + min(y_cal03)) / 2.0;
[h1, p1, muci1, zval1] = ttest(qr_t, miu_norm, 'Alpha', 0.05, 'Tail', 'left');
[h2, p2, muci2, zval2] = ttest(qr_t, miu_norm, 'Alpha', 0.025, 'Tail', 'left');
[h3, p3, muci3, zval3] = ttest(qr_t, miu_norm, 'Alpha', 0.010, 'Tail', 'left');
[h4, p4, muci4, zval4] = ttest(qr_t, miu_norm, 'Alpha', 0.001, 'Tail', 'left');


x_range = get(gca,'Xlim');
y_range = get(gca,'Ylim');
perc = 0.15;
%{
text_coord = [min(magn_qr_t) + perc * (max(magn_qr_t) - min(magn_qr_t)), ...
    max(y_cal03) - perc * (max(y_cal03) - min(y_cal03))];
%text_coord = [magn_qr_t(num_of_graph) / 1.5, max(qr_t) * 0.9];
%}
text_coord = [  x_range(1) + perc * (x_range(2) - x_range(1)), ...
                exp(log(y_range(1)) + perc * log((y_range(2) - y_range(1))))];

if h1 == 1
    if h2 == 1
        if h3 == 1
            if h4 == 1
                test_str = {['$$We\ ACCEPT\ T(n)=\mathcal{O} \left( \frac{log \left( 1/\varepsilon d \right)}{\varepsilon} \right)', ...
                    '\ without\ type-I\ error$$']; ...
                    '$$with\ probability\ p=99.9\% .$$';
                    };
            else
                test_str = {['$$We\ ACCEPT\ T(n)=\mathcal{O} \left( \frac{log \left( 1/\varepsilon d \right)}{\varepsilon} \right)', ...
                    '\ without\ type-I\ error$$']; ...
                    '$$with\ probability\ p=99.0\% .$$';
                    };
            end
        else
            test_str = {['$$We\ ACCEPT\ T(n)=\mathcal{O} \left( \frac{log \left( 1/\varepsilon d \right)}{\varepsilon} \right)', ...
                '\ without\ type-I\ error$$']; ...
                '$$with\ probability\ p=97.5\% .$$';
                }; 
        end
    else
        test_str = {['$$We\ ACCEPT\ T(n)=\mathcal{O} \left( \frac{log \left( 1/\varepsilon d \right)}{\varepsilon} \right)', ...
            '\ without\ type-I\ error$$']; ...
            '$$with\ probability\ p=95.0\% .$$';
            };
    end
else
    test_str = {['$$We\ CANNOT ACCEPT\ T(n)=\mathcal{O} \left( \frac{log^2 \left( 1/\varepsilon d \right)}{\varepsilon} \right)', ...
        '\ without\ type-I\ error$$']; ...
        '$$with\ probability\ p=95.0\% .$$';
        };
end
txt_hdl = text(text_coord(1), text_coord(2), test_str, ...
    'Interpreter', 'latex', 'FontSize', 15);
%set(txt_hdl, 'FontSmoothing', 'on');

%{
Rsq1 = 1 - sum((qr_t -  y_cal01).^2) / sum((qr_t - mean(qr_t)).^2);
Rsq2 = 1 - sum((qr_t -  y_cal02).^2) / sum((qr_t - mean(qr_t)).^2);
%}
%lgd = legend({'$\hat{\y} = {\beta}\hat{\x}$'},{'$\hat{\y} = {\beta}\hat{\x}$'}, 'Interpreter','latex');
lgd = legend('$$y=T(\varepsilon)$$', ...
    '$${y}=\frac{-16ln \left( 1-p \right)klog(d)log \left( 1/\varepsilon \right)d^{2-\frac{2}{k}}}{\varepsilon}$$', ...
    '$${y}=\frac{-8ln \left( 1-p \right)klog(d)log \left( 1/\varepsilon \right)d^{2-\frac{2}{k}}}{\varepsilon}$$');
set(lgd, 'Interpreter', 'latex');
set(lgd, 'FontSize', 12);
% title(lgd,'Legends');

%{
if stats(3) < alpha
    rel_sgn = '\leq';
    mood_sgn = 'CAN';
else
    rel_sgn = '\geq';
    mood_sgn = 'CANNOT';
end
%}

%{
perc = 0.2;

text_coord = [magn_qr_t(floor(num_of_graph * perc)), ...
    qr_t(floor(num_of_graph * perc)) * 0.5 +  qr_t(num_of_graph) / 2.2];

test_str = {['${R}_{1}=', num2str(Rsq1, 3), '$']; ...
    ['${R}_{2}=', num2str(Rsq2, '%.3f'), '$']; ...
    ['$p\left\{ {F}_{\alpha=', num2str(alpha, '%.3f'), '}(1, N-2)>', num2str(stats(2), '%.2e'), '\right\}', ...
    '=' ,num2str(stats(3), '%.3f'), rel_sgn, '\alpha', '$']; ...
    ['$$Thus\ we\ ', mood_sgn, '\ accept\ ','T(n)=\Theta \left( \frac{log \left( 1/\varepsilon d \right)}{\varepsilon d} \right)$$']; ...
    '$\mathcal{O}$'
    };
text(text_coord(1), text_coord(2), test_str, ...
    'Interpreter', 'latex', 'FontSize', 15);
%}
%{
title(['$Linear\ Regression\ of\ Queries\ for\ K=', num2str(K, '%d'), ...
    '\ ,\ N=', num2str(N, '%d'), '$'], 'Interpreter', 'latex', 'FontSize', 18);
%}
ylabel('$Queries$', 'Interpreter', 'latex', 'FontSize', 13);
xlabel('$$\varepsilon$$', 'Interpreter', 'latex', 'FontSize', 13);
