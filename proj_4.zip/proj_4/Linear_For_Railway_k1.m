
clear;
close all;
clc;

k1_record_txt = '.\fuqh_test2\record\result1.txt';
[py_t,qr_t] = textread(k1_record_txt,'%n%n'); %#ok<*DTXTRD>

bound_d = 12;                   % Bounded Degree
num_of_graph = 1000;            % Number of Testing Instances
epsilon_clique = 2 / (bound_d) ^2;        
                                % Recommended Epsilon for Cli-Con Grraphs

eps_list = zeros(num_of_graph, 1);
for i = 1 : num_of_graph
eps_list(i) = ((i - num_of_graph / 2) * ...
    (0.5 / (num_of_graph / 2)) + 1) * epsilon_clique;
end

magn_qr_t = (log(1 ./ (eps_list * bound_d))).^2 ./ eps_list;
% magn_qr_t = log(1 ./ (eps_list * bound_d)) ./ (eps_list * bound_d);

figure(1);

%{
b1 = magn_qr_t \ qr_t;
y_cal01= b1 * magn_qr_t;
plot(magn_qr_t, y_cal01, '--');
%}
scatter(magn_qr_t, qr_t, '.');
hold on;

alpha = 0.05;
AugMAG = [ones(length(magn_qr_t),1) magn_qr_t];
[b_new, bint, r_new, rint, stats] = regress(qr_t, AugMAG, alpha);
% b_new = AugMAG \ qr_t;

y_cal02 = AugMAG * b_new;
plot(magn_qr_t, y_cal02, 'r-');

axis tight;

% Rsq1 = 1 - sum((qr_t -  y_cal01).^2) / sum((qr_t - mean(qr_t)).^2);
Rsq2 = 1 - sum((qr_t -  y_cal02).^2) / sum((qr_t - mean(qr_t)).^2);

%lgd = legend({'$\hat{\y} = {\beta}\hat{\x}$'},{'$\hat{\y} = {\beta}\hat{\x}$'}, 'Interpreter','latex');
lgd = legend('$y=f(x)$', ...
    '${y}={\hat{\beta}}_{0} + {\hat{\beta}}_{1}{x}$');
set(lgd, 'Interpreter', 'latex');
set(lgd, 'FontSize', 12);
title(lgd,'Legends of Data');

if stats(3) < alpha
    rel_sgn = '\leq';
    mood_sgn = 'CAN';
else
    rel_sgn = '\geq';
    mood_sgn = 'CANNOT';
end

x_range = get(gca,'Xlim');
y_range = get(gca,'Ylim');
perc = 0.15;
%{
text_coord = [min(magn_qr_t) + perc * (max(magn_qr_t) - min(magn_qr_t)), ...
    max(y_cal03) - perc * (max(y_cal03) - min(y_cal03))];
%text_coord = [magn_qr_t(num_of_graph) / 1.5, max(qr_t) * 0.9];
%}
text_coord = [perc * x_range(2), (1 - perc) * y_range(2)];

test_str = {['$R=', num2str(Rsq2, '%.3f'), '$']; ...
    ['$p\left\{ {F}_{\alpha=', num2str(alpha, '%.3f'), '}(1, N-2)>', num2str(stats(2), '%.2e'), '\right\}', ...
    '=' ,num2str(stats(3), '%.3f'), rel_sgn, '\alpha', '$']; ...
    ['$$Thus\ we\ ', mood_sgn, '\ accept\ ','T(n)=\Theta \left( \frac{log^{2} \left( 1/\varepsilon d \right)}{\varepsilon} \right)$$'];
    };
text(text_coord(1), text_coord(2), test_str, ...
    'Interpreter', 'latex', 'FontSize', 15);

% title('$Linear\ Regression\ of\ Queries$', 'Interpreter', 'latex', 'FontSize', 18);
ylabel('$Queries$', 'Interpreter', 'latex', 'FontSize', 13);
xlabel('$$\frac{log^{2}\left( 1/\varepsilon d \right)}{\varepsilon}$$', 'Interpreter', 'latex', 'FontSize', 13);
