
clear;
close all;
clc;

k1_record_txt = '.\fuqh_test2\record\result1.txt';
[py_t,qr_t] = textread(k1_record_txt,'%n%n'); %#ok<*DTXTRD>

bound_d = 12;                   % Bounded Degree
num_of_graph = length(qr_t);    % Number of Testing Instances
epsilon_clique = 2 / (bound_d^2);
                                % Recommended Epsilon for Cli-Con Grraphs

eps_list = zeros(num_of_graph, 1);
for i = 1 : num_of_graph
eps_list(i) = ((i - num_of_graph / 2) * ...
    (0.5 / (num_of_graph / 2)) + 1) * epsilon_clique;
end

magn_qr_t = log(1 ./ (eps_list * bound_d)) ./ (eps_list * bound_d);

figure(1);

b1 = magn_qr_t \ qr_t;
y_cal01= b1 * magn_qr_t;
scatter(magn_qr_t, qr_t, '.');
hold on;

alpha = 0.05;
AugMAG = [ones(length(magn_qr_t),1) magn_qr_t];
[b_new, bint, r_new, rint, stats] = regress(qr_t, AugMAG, alpha);
% b_new = AugMAG \ qr_t;

y_cal02 = AugMAG * b_new;
plot(magn_qr_t, y_cal02, 'r-');
axis tight;

Rsq2 = 1 - sum((qr_t -  y_cal02).^2) / sum((qr_t - mean(qr_t)).^2);

lgd = legend('$y=T(\varepsilon)$', ...
    '${y}={\hat{\beta}}_{0} + {\hat{\beta}}_{1}{x}$');
set(lgd, 'Interpreter', 'latex');
set(lgd, 'FontSize', 12);
% title(lgd,'Legends');

VAR = var(qr_t);

if stats(3) < alpha
    rel_sgn = '\leq';
    mood_sgn = 'CAN';
else
    rel_sgn = '\geq';
    mood_sgn = 'CANNOT';
end

perc = 0.15;
text_coord = [min(magn_qr_t) + perc * (max(magn_qr_t) - min(magn_qr_t)), ...
    max(y_cal02) - perc * (max(y_cal02) - min(y_cal02))];

test_str = {['$${R}_{2}=', num2str(Rsq2, '%.3f'), '$$']; ...
    ['$$p\left\{ {F}_{1,\,N-2}(', num2str(alpha / 2, '%.3f'), ' )>', num2str(stats(2), '%.2e'), '\right\}', ...
    '=' ,num2str(stats(3), '%.3f'), rel_sgn, '\frac{\alpha}{2}', '$$']; ...
    ['$$Thus\ we\ ', mood_sgn, '\ accept\ ','T(n)=\Theta \left( \frac{log \left( 1/\varepsilon d \right)}{\varepsilon d} \right)$$'];
    };
text(text_coord(1), text_coord(2), test_str, ...
    'Interpreter', 'latex', 'FontSize', 15);

%title('$Linear\ Regression\ of\ Queries$', 'Interpreter', 'latex', 'FontSize', 18);
ylabel('$Queries$', 'Interpreter', 'latex', 'FontSize', 13);
xlabel('$$\frac{log \left( 1/\varepsilon d\right)}{\varepsilon d}$$', 'Interpreter', 'latex', 'FontSize', 13);
