// A simple program for testing connectivity. It uses the igraph library to read graphs.
// Compile using e.g. gcc -O2 --std=c99 -pedantic -lm zshg.c simplezshg.c -ligraph

// Philipp Klaus Krause, philipp@informatik.uni-frankfurt.de, pkk@spth.de, 2009 - 2017
// Copyright (c) 2014-2017 Philipp Klaus Krause
// Copyright (c) 2017 University of Leeds

// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>

#include "igraph.h"
#include "zshg.h"

// #define PRINT_TRAVERSAL_LIST 1
// #define SHOW_ADJACENT_MATRIX 1
// #define SHOW_VISITED_LIST 1
// #define PRINT_TESTING_RESULT 1
// #define PRINT_STACK 1

// Defined: Epsilons Will Increase Gradually
// Not Defined: Epsilons Will Fix
// #define EPSILON_SCALING 1

// Defined: Archipelagoes(with Instance_Mode = 1)
// Not Defined: Others
// #define ISLANDS_MODE 1

// 1: Random Graphs or Archipelago(with Islands_Mode = 1)
// Others: Railways
#define INSTANCE_MODE 2

// #define IMPROVED_TESTING_1 1
// #define IMPROVED_TESTING_2 1
// #define IMPROVED_TESTING_3 1

igraph_t igraph;

unsigned long queries;

zshg_index_t query_n(void)
{
	queries++;
	return(igraph_vcount(&igraph));
}

double query_d(void)
{
	queries++;
	return(2.0 * igraph_ecount(&igraph) / igraph_vcount(&igraph));
}

zshg_index_t query_degree(zshg_index_t v)
{
	queries++;
	igraph_vector_t vector;
	igraph_vector_init(&vector, 0);
	igraph_neighbors(&igraph, &vector, v, IGRAPH_ALL);
	zshg_index_t degree = igraph_vector_size(&vector);
	igraph_vector_destroy(&vector);
	return(degree);
}

zshg_index_t query_neighbour(zshg_index_t v, zshg_index_t i)
{
	queries++;
	igraph_vector_t vector;
	igraph_vector_init(&vector, 0);
	igraph_neighbors(&igraph, &vector, v, IGRAPH_ALL);
	zshg_index_t neighbor = (i < igraph_vector_size(&vector)) ? VECTOR(vector)[i] : ZSHG_INDEX_INVALID;
	igraph_vector_destroy(&vector);
	return(neighbor);
}

void usage(FILE *f)
{
	fprintf(f, "zshg - testing connectivity in constant time.\n");
	fprintf(f, "Usage: zshgd [--help] [--epsilon e] [--probability p] [--format f] filename\n");
	fprintf(f, "Supported epsilon range: ]0.0, 0.5[.\n");
	fprintf(f, "Supported probability range: ]0.0, 1.0[.\n");
	fprintf(f, "Supported formats: edgelist, ncol, graphdb, graphml, gml, pajek.\n");
}

/* *
* Deterministic DFS Core Traversal
* @param adjac[]: adjacent matrix
* @param ver_m: vertex "m" we visit now
* @param *visit_list: visited matrix
* @num_ver: number of vertices of input graph
* */
bool determ_dfs(int *adjac, int ver_m, int *visit_list, int num_ver, bool main_enter)
{
	int i;

	visit_list[ver_m] = 1;

#ifdef SHOW_VISITED_LIST
	printf("\n");
	for (i = 0; i < num_ver; i++)
		printf("%d ", visit_list[i]);
	printf("\n");
#endif

#ifdef PRINT_TRAVERSAL_LIST
	printf("%d -> ", ver_m);
#endif

	// Traverse the Graph
	for (i = 0; i < num_ver; i++)
	{
		// If vertex j has never been visited and <j, m> is an edge
		if (adjac[ver_m * num_ver + i] == 1 && !visit_list[i])
		{
			determ_dfs(adjac, i, visit_list, num_ver, false);
		}
	}

	if (main_enter)
		for (i = 0; i < num_ver; i++)
			if (visit_list[i] == 0) return false;

	return true;
}

/* *
* Deterministic DFS Traversal (by Stack)
* @param adjac[]: adjacent matrix
* @param ver_m: vertex "m" we visit now
* @param *visit_list: visited matrix
* @num_ver: number of vertices of input graph
* */
bool determ_dfs_stack(int *adjac, int ver_m, int num_ver)
{
	int i, top = 0;
	int *visit_list = (int *)calloc(num_ver, sizeof(int));
	int *stack_p = (int *)calloc(num_ver, sizeof(int));
	int *stack_mark = (int *)calloc(num_ver, sizeof(int));

	for (i = 0; i < num_ver; i++)
	{
		visit_list[i] = 0;
		stack_p[i] = -1;
		stack_mark[i] = 0;
	}
	visit_list[ver_m] = 1;
	stack_p[top] = ver_m;


#ifdef SHOW_VISITED_LIST
	printf("\n");
	for (i = 0; i < num_ver; i++)
		printf("%d ", visit_list[i]);
	printf("\n");
#endif

#ifdef PRINT_TRAVERSAL_LIST
	printf("%d -> ", ver_m);
#endif

	// Traverse the Graph
	while (top >= 0)
	{
		ver_m = stack_p[top];
		top--;
		visit_list[ver_m] = 1;

		for (i = 0; i < num_ver; i++)
		{
			// If vertex i has never been visited and <i, m> is an edge
			if (adjac[ver_m * num_ver + i] == 1 && !visit_list[i] && !stack_mark[i])
			{
				top++;
				stack_p[top] = i;
				stack_mark[i] = 1;
			}
		}

#ifdef PRINT_STACK
		printf("top = %d\n", top);
		for (i = 0; i <= top; i++)
		{
			printf("%d ", stack_p[i]);
		}
		printf("\n");
#endif
	}

	free(stack_mark);
	free(stack_p);

	for (i = 0; i < num_ver; i++)
		if (visit_list[i] == 0)
		{
			free(visit_list);
			return false;
		}

	free(visit_list);
	return true;
}

/* *
* Deterministic DFS Traversal Main Function
* @param adjac[]: adjacent matrix
* @param *visit_list: visited matrix
* @num_ver: number of vertices of input graph
* */
void determ_dfs_traverse(int *adjac, int *visit_list, int num_ver)
{
	int i;

	for (i = 0; i < num_ver; i++)
	{
		visit_list[i] = 0;
	}

	// Traverse Vertices
	{
		for (i = 0; i < num_ver; i++)
		{
			// If vertex i has never been visited
			if (!visit_list[i])
			{
				determ_dfs(adjac, i, visit_list, num_ver, false);
			}
		}
	}
}

int read_graph(const char *format, const char *filename)
{
	int ret;
	FILE *file;
	igraph_bool_t simple;

	// Open file
	if(!(file = fopen(filename, "r")))
	{
		printf("Failed to open file %s.\n", filename);
		return(-1);
	}
	
	// Read graph from file
	if(!strcmp("edgelist", format))
		ret = igraph_read_graph_edgelist(&igraph, file, 0, false);
	else if(!strcmp("ncol", format))
		ret = igraph_read_graph_ncol(&igraph, file, 0, false, IGRAPH_ADD_WEIGHTS_NO, IGRAPH_UNDIRECTED);
	else if(!strcmp("graphdb", format))
		ret = igraph_read_graph_graphdb(&igraph, file, false);
	else if(!strcmp("graphml", format))
		ret = igraph_read_graph_graphml(&igraph, file, 0);
	else if(!strcmp("gml", format))
		ret = igraph_read_graph_gml(&igraph, file);
	else if(!strcmp("pajek", format))
		ret = igraph_read_graph_pajek(&igraph, file);
	else
	{
		fclose(file);
		fprintf(stderr, "Unknown file format: %s.\n", format);
		usage(stderr);
		return(-1);
	}

	fclose(file);

	if(ret)
	{
		printf("Failed to read a graph from file %s.\n", filename);
		return(-1);
	}

	// Check for undirectedness
	if(igraph_is_directed(&igraph) || igraph_is_simple(&igraph, &simple) || !simple)
	{
		printf("Input is not a simple, undirected graph from file %s.\n", filename);
		igraph_destroy(&igraph);
		return(-1);
	}
	
	return(0);
}


int main(int argc, char *argv[])
{
	// Formal Utilities //
	putchar('\n');
	putchar('\n');
	printf("\t\t==============================================\n");
	printf("\t\t======                                  ======\n");
	printf("\t\t====                                      ====\n");
	printf("\t\t==          Graph Property Testing          ==\n");
	printf("\t\t====                                      ====\n");
	printf("\t\t======                                  ======\n");
	printf("\t\t==============================================\n");
	putchar('\n');

	putchar('\n');
	printf("\t\t         Algorithm Programmer: Qihong Fu       \n");
	printf("\t\t     Programming Platform: Microsoft VS2013    \n");
	printf("\t\t     Project Beginning Time: 20th Feb, 2019    \n");
	putchar('\n');
	putchar('\n');
	// Formal Utilities //


	// Initialisation Part (Default Values)
	unsigned long int n		= 6500;		// Recommend: 5e3
	unsigned long deg_bound = 12;		// Recommend: 10
	// F:\Learning_Resources_in_UK\Master Project\��������\matlab���\LinearIslands
	// F:\Learning_Resources_in_UK\Master Project\��������\matlab���\LinearRailways
	double epsilon_clique = (2.0 / (deg_bound * deg_bound));
										// epsilon set for islands
	unsigned long int graphsize_clique = (unsigned long)pow(2, deg_bound);
										// number of vertices as default

	double epsilon = 0.05;				// epsilon recommended
										// Recommend: 0.15 [OR] epsilon_clique
	double mul = 3.0;					// Recommend: 1.0
	double p = deg_bound * deg_bound * mul / n;
										// Recommend: deg_bound * deg_bound * mul / n;

	double probability		= 0.67;		// Recommend: 0.67
	int option				= -1; 
	int num_of_graph		= 1000;

#ifdef EPSILON_SCALING
	epsilon = epsilon_clique;
#endif

#ifdef VERTICES_SCALING
	n = graphsize_clique;
#endif

#ifdef DEGREE_SCALING
	deg_bound = (unsigned long)log2((double)n);
#endif

#ifdef ISLANDS_MODE
	p = 1.0;
	epsilon = epsilon_clique;
#endif


	/*
	LARGE_INTEGER nFreq = { 0 };
	LARGE_INTEGER nBeginTime = { 0 };
	LARGE_INTEGER nEndTime = { 0 };
	*/

	// double runtime;

	/* ======== Used Method ========
	QueryPerformanceFrequency(&nFreq);
	QueryPerformanceCoruntimeunter(&nBeginTime);
	...
	QueryPerformanceCounter(&nEndTime);
	runtime = (double)(nEndTime.QuadPart - nBeginTime.QuadPart) / (double)nFreq.QuadPart;
	======== Used Method ======== */


	// If needed, just modify the info below.
	FILE *graph_fp = NULL;
	FILE *rec_fp1 = NULL;
	FILE *rec_fp2 = NULL;
	FILE *rec_fp3 = NULL;

	FILE *info = NULL;
	


	const char *format = "edgelist";
	const char *filename = "graphlist\\path.edgelist";
	const char *record1 = "record\\result1.txt";
	const char *record2 = "record\\result2.txt";
	const char *record3 = "record\\result3.txt";

	clock_t t;

	/* DEFAULT OPTION */
	putchar('\n');
	printf("Would you like to run in default values below:\n");
	putchar('\n');

	printf("Boundary Parameter __epsilon__:           \t %.3g \n",		epsilon);
	printf("Probability for Acception/Rejection:      \t %.3g \n",		probability);
	printf("#{Vertices of Graph}:                     \t %ld \n",		n);
	printf("Probability for Random Graphs Generation: \t %.3g \n",		p);
	printf("Bound of Degree of Graphs:                \t %ld \n",		deg_bound);
	printf("Number of Testing Instances:              \t %d \n",		num_of_graph);
	putchar('\n');

	printf("Input '1' for __YES__ or '0' for __NO__: \t ");
	scanf("%d", &option);
	putchar('\n');

	if (option != 1 && option != 0)
	{
		putchar('\n');
		printf("Invalid Value! Please input your option again.\n");
		printf("Input '1' for __YES__ and '0' for __NO__: \t ");
		scanf("%d", &option);
		putchar('\n');
	}
	
	if (!option)
	{
		putchar('\n');
		printf("Please input your expected values below:\n");
		putchar('\n');

		printf("Please Input the Boundary Parameter __epsilon__ of Oracle:\t");
		scanf("%lf", &epsilon);
		printf("Please Input the Probability to Accept/Reject the Solution:\t");
		scanf("%lf", &probability);
		printf("Please Input the Number of Vertices of Graph:\t");
		scanf("%ld", &n);
		printf("Please Input the Multiplier of Probability for Random Generation:\t");
		scanf("%lf", &mul);

		p *= mul;
		if (p >= 1.0) p = 1.0;

		printf("Please Input the Bound of Degree of Graph:\t");
		scanf("%ld", &deg_bound);
		printf("Please Input the Number of Testing Graph:\t");
		scanf("%d", &num_of_graph);
		putchar('\n');
	}

	unsigned long i = 0, j = 0, k = 0;
	unsigned long *deg_g = (unsigned long *)malloc(sizeof(unsigned long) * n);
	int counter;


	// =============== Begin to Iterate Graph Testing =============== //
	// Generate A Number of Graphs and Test
	// Write Graphs into and Read them from ../graphlist/path.edgelist
	// Record Datum in ../record/result+k.txt, for k-connectivity testing

	rec_fp1 = fopen(record1, "w+");
	rec_fp2 = fopen(record2, "w+");
	rec_fp3 = fopen(record3, "w+");

	
	// Adjacent Matrix
	int *adj_mat = NULL;
	adj_mat = calloc(n * n, sizeof(int));
	if (!adj_mat)
	{
		printf("\n\nSorry! Memory allocation failed.\n\n");
		return 0;
	}
	

	// Initial adjaMat
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++)
			adj_mat[i * n + j] = 0;

	// boolean FLAG for STOCHASTICALLY testing whether the graph is k-connected
	bool maybe_connected, maybe_2_edge_connected, maybe_3_edge_connected;

	// boolean FLAG for DETERMINISTICALLY testing whether the graph is k-connected
	bool connected_k1_flag, connected_k2_flag, connected_k3_flag;

	// counter for the correct testings for k-connectivity
	int correct_k1_TRUE_test = 0, correct_k2_TRUE_test = 0, correct_k3_TRUE_test = 0;
	int correct_k1_FALSE_test = 0, correct_k2_FALSE_test = 0, correct_k3_FALSE_test = 0;

	int size_of_parallel; // = deg_bound
	int size_unit; // = (deg_bound / 3) > 3 ? 3 : (deg_bound / 3);
	int num_units; // = n / size_unit;
	int path_start;
	int process = 0;

	for (counter = 0; counter < num_of_graph; counter++)
	{
		// ================ Graph Generation Part Begins ================ //

#ifdef EPSILON_SCALING
// epsilon modification
		epsilon = (((float)counter - num_of_graph / 2.0) / num_of_graph + 1.0) \
			* epsilon_clique;
#endif

#ifdef VERTICES_SCALING
		// epsilon modification
		n = (int)(((float)counter - num_of_graph / 2.0)  / (2 * num_of_graph) + 1.0) \
			* epsilon_clique;
#endif

#ifdef DEGREE_SCALING
		// epsilon modification
		epsilon = (((float)counter - num_of_graph / 2.0) * 0.5 / (num_of_graph / 2.0) + 1.0) \
			* epsilon_clique;
#endif

		// Open the file for storage of graphs
		graph_fp = fopen(filename, "w+");

		// Seed to generate instances of testing graph
		srand((unsigned)time(NULL));
		

#if (INSTANCE_MODE == 1)		
		// ------ FIRST VERSION: RANDOM D-DEBOUNDED GRAPHS ------ //
		// ------- When p=1, it will generate ARCHIPELAGO ------- //
		for (i = 0; i < n; i++)
			deg_g[i] = 0;

		for (i = 0; i < n; i++)
		{
			for (j = i + 1; j < n; j++)
			{
				if (deg_g[i] >= deg_bound)
					break;
				if (deg_g[j] >= deg_bound)
					break;
				if (rand() <= RAND_MAX * p)
				{
					fprintf(graph_fp, "%lu %lu\n", i, j);
					deg_g[i]++;
					deg_g[j]++;
					adj_mat[i * n + j] = 1;	// a[i, j] = 1
					adj_mat[j * n + i] = 1; // a[j, i] = 1
				}
			}
		}
		

#else
		// ------ SECOND VERSION: RAILWAY ------
		size_of_parallel = deg_bound - 1;
		size_unit = 2 * size_of_parallel;
		num_units = n / size_unit;
		for (i = 0; i < num_units; i++)
		{
			for (j = 0; j < size_of_parallel; j++)
			{
				for (k = 0; k < size_of_parallel; k++)
				{
					// <2ip + j, (2i+1)p + k> is an edge
					// printf("<%d, %d> ", 2 * i * size_of_parallel + j, \
					(2 * i + 1) * size_of_parallel + k);
					fprintf(graph_fp, "%lu %lu\n", 2 * i * size_of_parallel + j, \
						(2 * i + 1) * size_of_parallel + k);
					adj_mat[(2 * i * size_of_parallel + j) * n + ((2 * i + 1) * size_of_parallel + k)] = 1;
					adj_mat[((2 * i + 1) * size_of_parallel + k) * n + (2 * i * size_of_parallel + j)] = 1;
				}
			}
			if (i != num_units - 1)
			{
				// <(2i + 1)p, 2(i + 1)p> is an edge
				fprintf(graph_fp, "%lu %lu\n", (2 * i + 1) * size_of_parallel, \
					2 * (i + 1) * size_of_parallel);
				adj_mat[(2 * i + 1) * size_of_parallel * n + (2 * (i + 1) * size_of_parallel)] = 1;
				adj_mat[(2 * (i + 1) * size_of_parallel) * n + (2 * i + 1) * size_of_parallel] = 1;
			}
		}
		// putchar('\n');

		path_start = (n / size_unit) * size_unit;
		if (n % size_unit)
		{
			// <start - p, start> is an edge
			fprintf(graph_fp, "%lu %lu\n", path_start - size_of_parallel, path_start);
			adj_mat[(path_start - size_of_parallel) * n + path_start] = 1;
			adj_mat[path_start * n + (path_start - size_of_parallel)] = 1;

			for (i = 0; i < n % size_unit - 1; i++)
			{
				// <start + i, start + i + 1> is an edge
				fprintf(graph_fp, "%lu %lu\n", path_start + i, path_start + i + 1);
				adj_mat[(path_start + i) * n + (path_start + i + 1)] = 1;
				adj_mat[(path_start + i + 1) * n + (path_start + i)] = 1;
			}
		}
#endif


#ifdef SHOW_ADJACENT_MATRIX
		// Test adjaMat
		printf("\n\n======== Testing Part ========\n\n");
		for (i = 0; i < n; i++)
		{
			for (j = 0; j < n; j++)
				printf(" %d", adj_mat[i * n + j]);
			printf("\n");
		}
		printf("\n\n======== Testing Part ========\n\n");
#endif	

		fclose(graph_fp);
		// ================ Graph Generation Part Ends ================ //


		// ================ Graph Testing Part Beginns ================ //
		// DFS Deterministically
		// for (1-edge-)Connectivity Testing
		// Starting Testing From Vertex 0
		// connected_k1_flag = determ_dfs(adj_mat, 0, visited, n, true);
		connected_k1_flag = determ_dfs_stack(adj_mat, 0, n);

		//  PRNG For Testing
		srand(clock());

		t = clock();
		if (read_graph(format, filename))
		{
			printf("System:\nFailed to read input graph in file %s.\n", filename);
			system("pause");
			return(-1);
		}

		// printf("\nLoading igraph: %ld msecs.\n", (long)(clock() - t));

		t = clock();
		queries = 0;

#ifdef IMPROVED_TESTING_1
		maybe_connected = zshg_imp(epsilon, probability);
#else
		maybe_connected = zshg(epsilon, probability);
#endif

		fprintf(rec_fp1, "%ld %lu\n", (long)(clock() - t), queries);

		/*
		else
		{
			printf("\nThe graph is unconnected.\n");
		}
		*/

		if (maybe_connected)
		{
			t = clock();
			queries = 0;

#ifdef IMPROVED_TESTING_2
			maybe_2_edge_connected = zshg2_imp(epsilon, probability);
#else
			maybe_2_edge_connected = zshg2(epsilon, probability);
#endif

			// printf("\n2-Connectivity Testing: %ld msecs, %lu queries.\n", (long)(clock() - t), queries);
			// 2-connectivity testing record
			fprintf(rec_fp2, "%ld %lu\n", (long)(clock() - t), queries);

			/*
			if (maybe_2_edge_connected)
			{
				//...
				putchar('\n');
				printf("The graph is considered to be 2-edge-connected.\n");
				printf("If it is %.3f - far from being connected,\n", epsilon);
				printf("this happens with probability at most %.1f%%.\n", 100.0 * (1.0 - probability));
				putchar('\n');
				//

				fprintf(rec_fp2, "%ld\t%lu\n", (long)(clock() - t), queries);
			}
			*/

			// else
				// printf("The graph is not 2-edge-connected.\n");
		}
		else
			maybe_2_edge_connected = false;

		if (maybe_2_edge_connected)
		{
			t = clock();
			queries = 0;
			
#ifdef IMPROVED_TESTING_3
			maybe_3_edge_connected = zshg3_imp(epsilon, probability);
#else
			maybe_3_edge_connected = zshg3(epsilon, probability);
#endif

			// printf("\n3-Connectivity Testing: %ld msecs, %lu queries.\n", (long)(clock() - t), queries);
			// 3-connectivity testing record
			fprintf(rec_fp3, "%ld %lu\n", (long)(clock() - t), queries);

			/*
			if (maybe_3_edge_connected)
			{
				//...
				putchar('\n');
				printf("The graph is considered to be 3-edge-connected.\n");
				printf("If it is %.3f - far from being connected,\n", epsilon);
				printf("this happens with probability at most %.1f%%.\n", 100.0 * (1.0 - probability));
				putchar('\n');
				//

				fprintf(rec_fp3, "%ld\t%lu\n", (long)(clock() - t), queries);
			}
			*/
			// else
				// printf("The graph is not 3-edge-connected.\n");
		}

		if ((counter + 1) % (num_of_graph / 20) == 0)
		{
			process++;
			if(process < 20)
				printf("%5.1f%% testings have been done...\n", 5.0 * process);
		}

		// Counting Correct Testings
#ifdef PRINT_TESTING_RESULT
		printf("FACT = %d, MAYBE = %d\n", connected_k1_flag, maybe_connected);
#endif
		if (connected_k1_flag && maybe_connected)
			correct_k1_TRUE_test++;
		if (!connected_k1_flag && !maybe_connected)
			correct_k1_FALSE_test++;
		igraph_destroy(&igraph);
	}

	// ================ Graph Testing Part Ends ================ //

	// igraph_destroy(&igraph);

	free(adj_mat);
	free(deg_g);
	fclose(rec_fp1);
	fclose(rec_fp2);
	fclose(rec_fp3);

	putchar('\n');
	printf("Solution has been saved successfully.\n");
	putchar('\n');
	system("pause");

	printf("\n============ ACCURACIES ============\n");
	if (correct_k1_TRUE_test)
		printf("1-edge-connected testing(ACCEPT): %3.6f", (float)correct_k1_TRUE_test / (float)num_of_graph);
	if (correct_k1_TRUE_test && correct_k1_FALSE_test)
		putchar('\n');
	if (correct_k1_FALSE_test)
		printf("1-edge-connected testing(REJECT): %3.6f", (float)correct_k1_FALSE_test / (float)num_of_graph);

	printf("\n====================================\n");

	return 0;
}
