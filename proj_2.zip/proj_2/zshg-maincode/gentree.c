#include <stdlib.h>
#include <stdio.h>

int main(int argc, char **argv)
{
	if(argc != 3)
	{
		fprintf(stderr, "Too few arguments. Use \"gentree n p\" to generate a path of length n with each edge (except the last) omitted with probability p\n");
		return(-1);
	}

	unsigned long int n = atol(argv[1]);
	double p = atof(argv[2]);

	srand(1); // Workaround for OpenBSD bug.

	if(n < 2)
	{
		fprintf(stderr, "Path too short.\n");
		return(-1);
	}

	if(p < 0.0 || p > 1.0)
	{
		fprintf(stderr, "Invalid probabilty.\n");
		return(-1);
	}

	for(unsigned long i = 0; i < n - 1; i++)
		if(rand() <= RAND_MAX - RAND_MAX * p)
			printf("%lu %lu\n", i, i + 1);
	printf("%lu %lu\n", n - 1, n);

	return(0);
}

