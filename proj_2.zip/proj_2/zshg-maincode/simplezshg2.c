// A simple program for testing connectivity. It uses the igraph library to read graphs.
// Compile using e.g. gcc -O2 --std=c99 -pedantic -lm zshg.c simplezshg.c -ligraph

// Philipp Klaus Krause, philipp@informatik.uni-frankfurt.de, pkk@spth.de, 2009 - 2017
// Copyright (c) 2014-2017 Philipp Klaus Krause
// Copyright (c) 2017 University of Leeds

// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <Winbase.h>

#include "igraph.h"

#include "zshg.h"

igraph_t igraph;

unsigned long queries;

zshg_index_t query_n(void)
{
	queries++;
	return(igraph_vcount(&igraph));
}

double query_d(void)
{
	queries++;
	return(2.0 * igraph_ecount(&igraph) / igraph_vcount(&igraph));
}

zshg_index_t query_degree(zshg_index_t v)
{
	queries++;
	igraph_vector_t vector;
	igraph_vector_init(&vector, 0);
	igraph_neighbors(&igraph, &vector, v, IGRAPH_ALL);
	zshg_index_t degree = igraph_vector_size(&vector);
	igraph_vector_destroy(&vector);
	return(degree);
}

zshg_index_t query_neighbour(zshg_index_t v, zshg_index_t i)
{
	queries++;
	igraph_vector_t vector;
	igraph_vector_init(&vector, 0);
	igraph_neighbors(&igraph, &vector, v, IGRAPH_ALL);
	zshg_index_t neighbor = (i < igraph_vector_size(&vector)) ? VECTOR(vector)[i] : ZSHG_INDEX_INVALID;
	igraph_vector_destroy(&vector);
	return(neighbor);
}

void usage(FILE *f)
{
	fprintf(f, "zshg - testing connectivity in constant time.\n");
	fprintf(f, "Usage: zshgd [--help] [--epsilon e] [--probability p] [--format f] filename\n");
	fprintf(f, "Supported epsilon range: ]0.0, 0.5[.\n");
	fprintf(f, "Supported probability range: ]0.0, 1.0[.\n");
	fprintf(f, "Supported formats: edgelist, ncol, graphdb, graphml, gml, pajek.\n");
}

int read_graph(const char *format, const char *filename)
{
	int ret;
	FILE *file;
	igraph_bool_t simple;

	// Open file
	if(!(file = fopen(filename, "r")))
	{
		printf("Failed to open file %s.\n", filename);
		return(-1);
	}
	
	// Read graph from file
	if(!strcmp("edgelist", format))
		ret = igraph_read_graph_edgelist(&igraph, file, 0, false);
	else if(!strcmp("ncol", format))
		ret = igraph_read_graph_ncol(&igraph, file, 0, false, IGRAPH_ADD_WEIGHTS_NO, IGRAPH_UNDIRECTED);
	else if(!strcmp("graphdb", format))
		ret = igraph_read_graph_graphdb(&igraph, file, false);
	else if(!strcmp("graphml", format))
		ret = igraph_read_graph_graphml(&igraph, file, 0);
	else if(!strcmp("gml", format))
		ret = igraph_read_graph_gml(&igraph, file);
	else if(!strcmp("pajek", format))
		ret = igraph_read_graph_pajek(&igraph, file);
	else
	{
		fclose(file);
		fprintf(stderr, "Unknown file format: %s.\n", format);
		usage(stderr);
		return(-1);
	}

	fclose(file);

	if(ret)
	{
		printf("Failed to read a graph from file %s.\n", filename);
		return(-1);
	}

	// Check for undirectedness
	if(igraph_is_directed(&igraph) || igraph_is_simple(&igraph, &simple) || !simple)
	{
		printf("Input is not a simple, undirected graph from file %s.\n", filename);
		igraph_destroy(&igraph);
		return(-1);
	}
	
	return(0);
}


int main(int argc, char *argv[])
{
	// Formal Utilities //
	putchar('\n');
	putchar('\n');
	printf("\t\t==============================================\n");
	printf("\t\t======                                  ======\n");
	printf("\t\t====                                      ====\n");
	printf("\t\t==          Graph Property Testing          ==\n");
	printf("\t\t====                                      ====\n");
	printf("\t\t======                                  ======\n");
	printf("\t\t==============================================\n");
	putchar('\n');

	putchar('\n');
	printf("\t\t         Algorithm Programmer: Qihong Fu       \n");
	printf("\t\t     Programming Platform: Microsoft VS2013    \n");
	printf("\t\t     Project Beginning Time: 20th Feb, 2019    \n");
	putchar('\n');
	putchar('\n');
	// Formal Utilities //

	// ================ Graph Generation Part Begins ================ //
	// Generate A Number of Graphs and Test
	// Write Graphs into and Read them from ../graphlist/path.edgelist
	// Record Datum in ../record/res.txt

	// Initialisation Part (Default Values)
	unsigned long int n = 500000;
	double p = 0.0005;
	unsigned long deg_bound = 5;
	double epsilon = 0.25;
	double probability = 0.85;
	int option = -1;
	int num_of_graph = 200;

	LARGE_INTEGER nFreq = { 0 };
	LARGE_INTEGER nBeginTime = { 0 };
	LARGE_INTEGER nEndTime = { 0 };

	double runtime;

	/* ======== Used Method ========
	QueryPerformanceFrequency(&nFreq);
	QueryPerformanceCoruntimeunter(&nBeginTime);
	...
	QueryPerformanceCounter(&nEndTime);
	runtime = (double)(nEndTime.QuadPart - nBeginTime.QuadPart) / (double)nFreq.QuadPart;
	======== Used Method ======== */

	// If needed, just modify the info below.
	FILE *graph_fp = NULL;
	const char *format = "edgelist";
	const char *filename = "graphlist\\path.edgelist";

	/* DEFAULT OPTION */
	putchar('\n');
	printf("Would you like to run in default values below:\n");
	putchar('\n');

	printf("Boundary Parameter __epsilon__:           \t %.3lf \n",		epsilon);
	printf("Probability for Acception/Rejection:      \t %.3lf \n",		probability);
	printf("#{Vertices of Graph}:                     \t %ld \n",		n);
	printf("Probability for Random Graphs Generation: \t %.3lf \n",		p);
	printf("Bound of Degree of Graphs:                \t %ld \n",		deg_bound);
	printf("Number of Testing Graphs:                 \t %d \n",		num_of_graph);
	putchar('\n');

	printf("Input '1' for __YES__ and '0' for __NO__: \t ");
	scanf("%d", &option);
	putchar('\n');

	if (option != 1 && option != 0)
	{
		putchar('\n');
		printf("Invalid Value! Please input your option again.\n");
		printf("Input '1' for __YES__ and '0' for __NO__: \t ");
		scanf("%d", &option);
		putchar('\n');
	}
	
	if (!option)
	{
		putchar('\n');
		printf("Please input your expected values below:\n");
		putchar('\n');

		printf("Please Input the Boundary Parameter __epsilon__ of Oracle:\t");
		scanf("%lf", &epsilon);
		printf("Please Input the Probability to Accept/Reject the Solution:\t");
		scanf("%lf", &probability);
		printf("Please Input the Expected Number of Vertices of Graph:\t");
		scanf("%ld", &n);
		printf("Please Input the Probability for Generating Random Graph:\t");
		scanf("%lf", &p);
		printf("Please Input the Bound of Degree of Graph:\t");
		scanf("%ld", &deg_bound);
		printf("Please Input the Number of Testing Graph:\t");
		scanf("%d", &num_of_graph);
		putchar('\n');
	}

	// Open files for storage of graphs
	graph_fp = fopen(filename, "w+");
	
	srand((unsigned)time(NULL));	// Generate my own graph.

	unsigned long i = 0, j = 0;
	unsigned long *deg_g = (unsigned long *)malloc(sizeof(unsigned long) * n);

	for (i = 0; i < n; i++)
		deg_g[i] = 0;

	for (i = 0; i < n; i++)
	{
		for (j = i + 1; j < n; j++)
		{
			if (deg_g[i] >= deg_bound)
				break;
			if (deg_g[j] >= deg_bound)
				break;
			if (rand() <= RAND_MAX * (1.0 - p))
			{
				fprintf(graph_fp, "%lu %lu\n", i, j);
				deg_g[i]++;
				deg_g[j]++;
			}
		}
	}

	fclose(graph_fp);

	printf("\nGraph Generation Completed!\n"); 
	// ================ Graph Generation Part Ends ================ //

	srand(clock());			//  PRNG For Testing

	clock_t t = clock();

	if (read_graph(format, filename))
	{
		printf("System:\nFailed to read input graph in file %s.\n", filename);
		system("pause");
		return(-1);
	}

	printf("\nLoading igraph: %ld msecs.\n", (long)(clock() - t));

	bool maybe_connected, maybe_2_edge_connected, maybe_3_edge_connected;

	// Run the First Clock for Connectivity-Testing
	QueryPerformanceFrequency(&nFreq);
	QueryPerformanceCoruntimeunter(&nBeginTime);

	queries = 0;
	maybe_connected = zshg(epsilon, probability);

	QueryPerformanceCounter(&nEndTime);
	runtime = (double)(nEndTime.QuadPart - nBeginTime.QuadPart) / (double)nFreq.QuadPart;

	printf("\nConnectivity Testing: %lf secs, %lu queries.\n", runtime, queries);

	if (maybe_connected)
	{
		putchar('\n');
		printf("The graph is considered to be connected.\n");
		printf("If it is %.3f - far from being connected,\n", epsilon);
		printf("this happens with probability at most %.1f%%.\n", 100.0 * (1.0 - probability));
		putchar('\n');
	}
	else
		printf("\nThe graph is unconnected.\n");

	if (maybe_connected)
	{
		// Run the Second Clock for 2-Connectivity-Testing
		QueryPerformanceFrequency(&nFreq);
		QueryPerformanceCoruntimeunter(&nBeginTime);

		queries = 0;
		maybe_2_edge_connected = zshg2(epsilon, probability);

		QueryPerformanceCounter(&nEndTime);
		runtime = (double)(nEndTime.QuadPart - nBeginTime.QuadPart) / (double)nFreq.QuadPart;
		printf("\n2-Connetivity-Testing: %lf msecs, %lu queries\n", runtime, queries);

		if (maybe_2_edge_connected)
		{
			putchar('\n');
			printf("The graph is considered to be 2-edge-connected.\n");
			printf("If it is %.3f - far from being connected,\n", epsilon);
			printf("this happens with probability at most %.1f%%.\n", 100.0 * (1.0 - probability));
			putchar('\n');
		}
		else
			printf("The graph is not 2-edge-connected.\n");
	}
	else
		maybe_2_edge_connected = false;

	if (maybe_2_edge_connected)
	{
		// Run the Third Clock for 2-Connectivity-Testing
		QueryPerformanceFrequency(&nFreq);
		QueryPerformanceCoruntimeunter(&nBeginTime);

		queries = 0;
		maybe_3_edge_connected = zshg3(epsilon, probability);

		QueryPerformanceCounter(&nEndTime);
		runtime = (double)(nEndTime.QuadPart - nBeginTime.QuadPart) / (double)nFreq.QuadPart;
		printf("\n3-Connetivity-Testing: %lf msecs, %lu queries\n", runtime, queries);

		if (maybe_3_edge_connected)
		{
			putchar('\n');
			printf("The graph is considered to be 3-edge-connected.\n");
			printf("If it is %.3f - far from being connected,\n", epsilon);
			printf("this happens with probability at most %.1f%%.\n", 100.0 * (1.0 - probability));
			putchar('\n');
		}
		else
			printf("The graph is not 3-edge-connected.\n");
	}

	igraph_destroy(&igraph);
	printf("Solution has been shown above.\n");
	putchar('\n');
	system("pause");

	return(0);
}
