// Connectivity test for graphs.

// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "zshg.h"

// Get a random index in the range [0;n].
static zshg_index_t rand_index(zshg_index_t n)
{
	return(rand() % n);
}

// A hashtable implementation used to track visited nodes in depth-first-search
struct visits_map_element
{
	zshg_index_t index;
	bool visited;
};

struct visits
{
	zshg_index_t size;
	struct visits_map_element *map;
};

typedef struct visits visits_t;

static void init_visits(visits_t *visits, zshg_index_t r)
{
	visits->size = r * 2;
	visits->map = malloc(visits->size * sizeof(struct visits_map_element));
	for(zshg_index_t i = 0; i < visits->size; i++)
	{
		visits->map[i].index = ZSHG_INDEX_INVALID;
		visits->map[i].visited = false;
	}
}

static void destroy_visits(visits_t *visits)
{
	free(visits->map);
}

static bool visited(const visits_t *visits, zshg_index_t v)
{
	for(struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
		if(e->index == ZSHG_INDEX_INVALID)
			return(false);
		else if(e->index == v)
			return(e->visited);
}

static void visit(visits_t *visits, zshg_index_t v)
{
	for(struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
	{
		if(e->index == ZSHG_INDEX_INVALID)
			e->index = v;
		else if(e->index != v)
			continue;

		e->visited = true;
		break;
	}
}

// Helper function for depth-first-search. Visit up to r nodes by dfs starting at v. Return r minus the number of nodes visited.
static zshg_index_t dfs_impl(zshg_index_t v, zshg_index_t r, struct visits *visits)
{
	if(!r)
		return(0);

	visit(visits, v);
	r--;

	zshg_index_t d = query_degree(v);

	for(zshg_index_t i = 0; i < d && r; i++)
	{
		zshg_index_t n = query_neighbour(v, i);

		if(visited(visits, n))
			continue;

		r = dfs_impl(n, r, visits);
	}

	return(r);
}

// Depth-first-search. Get the number of nodes found from v by depth-first-search up to r.
static zshg_index_t dfs(zshg_index_t v, zshg_index_t r)
{
	visits_t visits;

	init_visits(&visits, r);

	r -= dfs_impl(v, r, &visits);

	destroy_visits(&visits);

	return(r);
}

bool zshg_impl(double e, double p, uint_fast8_t k, zshg_index_t(*k_set)(zshg_index_t, zshg_index_t))
{
	zshg_index_t n = query_n();
	double d = query_d();
	double q = -log(1 - p);

	if (!n)
		return(false);
	if (d < 1)
		return(n == 1);

	double l = log2(8.0 / (e * d));

	if (n <= 16.0 * q * k * l / (e * d))
		return((*k_set)(0, n) == n);

	for (zshg_index_t i = 1; i <= l; i++)
	{
		zshg_index_t r = (1 << i);
		zshg_index_t m = 16.0 * q * k * l / (r * e * d);

		for (zshg_index_t c = 0; c <= m; c++)
		{
			zshg_index_t s = rand_index(n);

			if ((*k_set)(s, r) < r)
				return(false);
		}
	}

	return(true);
}


// Connectivity test.
// Complexity: O(-log(1 - p) log(1 / (ed)) / (e^2 d^2)), i.e. independent of the graph size and constant for fixed e, p and d.
// Returns true for connected graphs.
// Returns false with probability at least p for graphs that are e-far from connectivity.
bool zshg(double e, double p)
{
	return(zshg_impl(e, p, 1, &dfs));
}
