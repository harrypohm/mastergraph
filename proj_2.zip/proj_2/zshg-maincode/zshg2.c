// 2-edge-connectivity and 3-edge-connectivity tests for graphs.

// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "zshg.h"

// A hashtable implementation used to track visited nodes in depth-first-search
struct visits_map_element
{
	zshg_index_t index;
	bool visited;
	zshg_index_t from;
};

struct visits
{
	zshg_index_t size;
	struct visits_map_element *map;
};

typedef struct visits visits_t;

static void init_visits(visits_t *visits, zshg_index_t r)
{
	visits->size = r * 2;
	visits->map = malloc(visits->size * sizeof(struct visits_map_element));
	for(zshg_index_t i = 0; i < visits->size; i++)
	{
		visits->map[i].index = ZSHG_INDEX_INVALID;
		visits->map[i].visited = false;
		visits->map[i].from = ZSHG_INDEX_INVALID;
	}
}

static void init_visits2(visits_t *visits)
{
	for(zshg_index_t i = 0; i < visits->size; i++)
		visits->map[i].visited = false;
}

static void destroy_visits(visits_t *visits)
{
	free(visits->map);
}

static bool visited(const visits_t *visits, zshg_index_t v)
{
	for(struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
		if(e->index == ZSHG_INDEX_INVALID)
			return(false);
		else if(e->index == v)
			return(e->visited);
}

static bool visited2(const visits_t *visits, zshg_index_t v, zshg_index_t from)
{
	for(struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
		if(e->index == ZSHG_INDEX_INVALID)
			return(false);
		else if(e->index == v)
			return(e->visited || e->from == from);
}

static void visit(visits_t *visits, zshg_index_t v, zshg_index_t from)
{
	for(struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
	{
		if(e->index == ZSHG_INDEX_INVALID)
			e->index = v;
		else if(e->index != v)
			continue;

		e->visited = true;
		e->from = from;
		break;
	}
}

static void visit2(visits_t *visits, zshg_index_t v)
{
	for(struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
	{
		if(e->index == ZSHG_INDEX_INVALID)
			e->index = v;
		else if(e->index != v)
			continue;

		e->visited = true;
		break;
	}
}

// Helper function for first depth-first-search.
// Visit up to r nodes by dfs starting at v.
// On the graph without the edge between forbidden0 and forbidden1.
// Return r minus the number of nodes visited.
static zshg_index_t dfs_impl(zshg_index_t v, zshg_index_t r, zshg_index_t from, struct visits *visits, zshg_index_t forbidden0, zshg_index_t forbidden1)
{
	if(!r)
		return(0);

	visit(visits, v, from);
	r--;

	zshg_index_t d = query_degree(v);

	for(zshg_index_t i = 0; i < d && r; i++)
	{
		zshg_index_t n = query_neighbour(v, i);

		if(v == forbidden0 && n == forbidden1 || n == forbidden0 && v == forbidden1)
			continue;

		if(visited(visits, n))
			continue;

		r = dfs_impl(n, r, v, visits, forbidden0, forbidden1);
	}

	return(r);
}

// Helper function for second depth-first-search (where edges are never used in the same direction as during the first one).
// Visit up to r nodes by dfs starting at v.
// On the graph without the edge between forbidden0 and forbidden1.
// Return r minus the number of nodes visited.
static zshg_index_t dfs2_impl(zshg_index_t v, zshg_index_t r, zshg_index_t from, struct visits *visits, zshg_index_t forbidden0, zshg_index_t forbidden1)
{
	if(!r)
		return(0);

	visit2(visits, v);
	r--;

	zshg_index_t d = query_degree(v);

	for(zshg_index_t i = 0; i < d && r; i++)
	{
		zshg_index_t n = query_neighbour(v, i);

		if(v == forbidden0 && n == forbidden1 || n == forbidden0 && v == forbidden1)
			continue;

		if(visited2(visits, n, v))
			continue;

		r = dfs2_impl(n, r, v, visits, forbidden0, forbidden1);
	}

	return(r);
}

// Check if s is in a 2-set of size up to r in the graph without the edge between forbidden0 and forbidden1
static zshg_index_t set2_impl(zshg_index_t s, zshg_index_t r, zshg_index_t forbidden0, zshg_index_t forbidden1)
{
	zshg_index_t n;
	visits_t visits;

	init_visits(&visits, r);

	n = r - dfs_impl(s, r, ZSHG_INDEX_INVALID, &visits, forbidden0, forbidden1);

	if(n == r)
	{
		init_visits2(&visits);
		n = r - dfs2_impl(s, r, ZSHG_INDEX_INVALID, &visits, forbidden0, forbidden1);
	}

	destroy_visits(&visits);

	return(n);
}

// Check if s is in a 2-set of size up to r
static zshg_index_t set2(zshg_index_t s, zshg_index_t r)
{
	return(set2_impl(s, r, ZSHG_INDEX_INVALID, ZSHG_INDEX_INVALID));
}

// Check if s is in a 3-set size up to r
static zshg_index_t set3(zshg_index_t s, zshg_index_t r)
{
	zshg_index_t n;
	visits_t visits;

	init_visits(&visits, r);

	n = r - dfs_impl(s, r, ZSHG_INDEX_INVALID, &visits, ZSHG_INDEX_INVALID, ZSHG_INDEX_INVALID);

	if(n == r)
		for(zshg_index_t i = 0; i < visits.size; i++)
		{
			if(visits.map[i].index == ZSHG_INDEX_INVALID || visits.map[i].from == ZSHG_INDEX_INVALID)
				continue;

			n = set2_impl(s, r, visits.map[i].index, visits.map[i].from);

			if(n < r)
				break;
		}

	destroy_visits(&visits);

	return(n);
}

// 2-edge-connectivity test.
// Returns true for connected graphs.
// Returns false with probability at least p for graphs that are e-far from connectivity.
bool zshg2(double e, double p)
{
	return(zshg_impl(e, p, 2, set2));
}

// 3-edge-connectivity test.
// Returns true for connected graphs.
// Returns false with probability at least p for graphs that are e-far from connectivity.
bool zshg3(double e, double p)
{
	return(zshg_impl(e, p, 3, set3));
}