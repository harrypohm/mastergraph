
// Connectivity Testing for Graphs.

#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include <stdint.h>
#include <stdbool.h>

typedef uint_fast64_t zshg_index_t;
#define ZSHG_INDEX_INVALID UINT_FAST64_MAX
#define ZSHG_INDEX_MAX (UINT_FAST64_MAX - 1)

bool zshg_impl(double e, double p, uint_fast8_t k, zshg_index_t(*k_comp)(zshg_index_t, zshg_index_t));
bool zshg(double e, double p);  // Return true if graph is connected, return false with probability at least p, if graph is e-far from being connected.
bool zshg2(double e, double p); // Return true if graph is 2-edge-connected, return false with probability at least p, if graph is e-far from being connected.
bool zshg3(double e, double p); // Return true if graph is 3-edge-connected, return false with probability at least p, if graph is e-far from being connected.

zshg_index_t query_n(void); // Get number of nodes in graph
double query_d(void); // Get an upper bound on the average degree in the graph (e.g. the maximum degree)
zshg_index_t query_degree(zshg_index_t v); // Get degree of v
zshg_index_t query_neighbour(zshg_index_t v, zshg_index_t i); // Get i-th neighbour of v


// A hashtable implementation used to track visited nodes in DFS.
struct visits_map_element
{
	zshg_index_t index;
	bool visited;
	zshg_index_t from;
};

struct visits
{
	zshg_index_t size;
	struct visits_map_element *map;
};

// Get a random index in the range [0..n].
static zshg_index_t rand_index(zshg_index_t n)
{
	return(rand() % n);
}

typedef struct visits visits_t;

static void init_visits(visits_t *visits, zshg_index_t r)
{
	visits->size = r * 2;
	visits->map = malloc(visits->size * sizeof(struct visits_map_element));
	for (zshg_index_t i = 0; i < visits->size; i++)
	{
		visits->map[i].index = ZSHG_INDEX_INVALID;
		visits->map[i].visited = false;
		visits->map[i].from = ZSHG_INDEX_INVALID;
	}
}

static void destroy_visits(visits_t *visits)
{
	free(visits->map);
}

static bool visited(const visits_t *visits, zshg_index_t v)
{
	for (struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
	if (e->index == ZSHG_INDEX_INVALID)
		return(false);
	else if (e->index == v)
		return(e->visited);
}

static void visit(visits_t *visits, zshg_index_t v, zshg_index_t from)
{
	for (struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
	{
		if (e->index == ZSHG_INDEX_INVALID)
			e->index = v;
		else if (e->index != v)
			continue;

		e->visited = true;
		e->from = from;
		break;
	}
}

// Helper function for first DFS.
// Visit up to r nodes by dfs starting at v.
// On the graph without the edge between forbidden0 and forbidden1.
// Return r minus the number of nodes visited.
static zshg_index_t dfs_impl(zshg_index_t v, zshg_index_t r, zshg_index_t from, struct visits *visits, zshg_index_t forbidden0, zshg_index_t forbidden1)
{
	if (!r)
		return(0);

	visit(visits, v, from);
	r--;

	zshg_index_t d = query_degree(v);

	for (zshg_index_t i = 0; i < d && r; i++)
	{
		zshg_index_t n = query_neighbour(v, i);

		if (v == forbidden0 && n == forbidden1 || n == forbidden0 && v == forbidden1)
			continue;

		if (visited(visits, n))
			continue;

		r = dfs_impl(n, r, v, visits, forbidden0, forbidden1);
	}

	return(r);
}

// visit_dfs1(...) is a dfs function for function dfs_dfs1(...) only.
static void visit_dfs1(visits_t *visits, zshg_index_t v)
{
	for (struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
	{
		if (e->index == ZSHG_INDEX_INVALID)
			e->index = v;
		else if (e->index != v)
			continue;

		e->visited = true;
		break;
	}
}

// dfs_impl_dfs1(...) is a dfs function for function dfs(...) only.
static zshg_index_t dfs_impl_dfs1(zshg_index_t v, zshg_index_t r, struct visits *visits)
{
	if (!r)
		return(0);

	visit_dfs1(visits, v);
	r--;

	zshg_index_t d = query_degree(v);

	for (zshg_index_t i = 0; i < d && r; i++)
	{
		zshg_index_t n = query_neighbour(v, i);

		if (visited(visits, n))
			continue;

		r = dfs_impl_dfs1(n, r, visits);
	}

	return(r);
}

// DFS. Get the number of nodes found from v by DFS up to r.
static zshg_index_t dfs(zshg_index_t v, zshg_index_t r)
{
	visits_t visits;

	init_visits(&visits, r);

	r -= dfs_impl_dfs1(v, r, &visits);

	destroy_visits(&visits);

	return(r);
}

bool zshg_impl(double e, double p, uint_fast8_t k, zshg_index_t(*k_set)(zshg_index_t, zshg_index_t))
{
	zshg_index_t n = query_n();
	double d = query_d();
	double q = -log(1 - p);

	if (!n)
		return(false);
	if (d < 1)
		return(n == 1);

	double l = log2(8.0 / (e * d));

	if (n <= 16.0 * q * k * l / (e * d))
		return((*k_set)(0, n) == n);

	for (zshg_index_t i = 1; i <= l; i++)
	{
		zshg_index_t r = (1 << i);
		zshg_index_t m = 16.0 * q * k * l / (r * e * d);

		for (zshg_index_t c = 0; c <= m; c++)
		{
			zshg_index_t s = rand_index(n);

			if ((*k_set)(s, r) < r)
				return(false);
		}
	}

	return(true);
}


bool zshg_impl_imp(double e, double p, uint_fast8_t k, zshg_index_t(*k_set)(zshg_index_t, zshg_index_t))
{
	zshg_index_t n = query_n();
	double d = query_d();
	double q = -log(1 - p);

	if (!n)
		return(false);
	if (d < 1)
		return(n == 1);

	double l = log2(8.0 / (e * d));

	if (n <= 32.0 * q * k * l / (e * d))
		return((*k_set)(0, n) == n);

	int FLAG = 1;
	int counter = 0;
	for (zshg_index_t timer = 1; timer <= 18 * q; timer++)
	{
		FLAG = 1;
		for (zshg_index_t i = 1; i <= l; i++)
		{
			zshg_index_t r = (1 << i);
			zshg_index_t m = 32.0 * k * l / (r * e * d);

			for (zshg_index_t c = 0; c <= m; c++)
			{
				zshg_index_t s = rand_index(n);
				if ((*k_set)(s, r) < r)
					FLAG = 0;
			}
			if (FLAG == 0) break;
		}
		if (FLAG == 0) continue;
		else counter++;
	}

	if (counter >= 9 * q)
		return(false);
	else
		return(true);
}


// Connectivity Testing.
// Complexity: O(- log(1 - p) * (log(1 / (e * d))^2) / e)
// i.e. Independent of the graph size and constant for fixed e, p and d.
// Returns true for connected graphs.
// Returns false with probability at least p for graphs that are e-far from connectivity.
bool zshg(double e, double p)
{
	return(zshg_impl(e, p, 1, &dfs));
}

bool zshg_imp(double e, double p)
{
	return(zshg_impl_imp(e, p, 1, &dfs));
}

typedef struct visits visits_t;

static void init_visits2(visits_t *visits)
{
	for (zshg_index_t i = 0; i < visits->size; i++)
		visits->map[i].visited = false;
}

static bool visited2(const visits_t *visits, zshg_index_t v, zshg_index_t from)
{
	for (struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
	if (e->index == ZSHG_INDEX_INVALID)
		return(false);
	else if (e->index == v)
		return(e->visited || e->from == from);
}

static void visit2(visits_t *visits, zshg_index_t v)
{
	for (struct visits_map_element *e = visits->map + v % visits->size;; e = (e + 1 < visits->map + visits->size) ? (e + 1) : visits->map)
	{
		if (e->index == ZSHG_INDEX_INVALID)
			e->index = v;
		else if (e->index != v)
			continue;

		e->visited = true;
		break;
	}
}

// Helper function for second DFS (where edges are never used in the same direction as during the first one).
// Visit up to r nodes by dfs starting at v.
// On the graph without the edge between forbidden0 and forbidden1.
// Return r minus the number of nodes visited.
static zshg_index_t dfs2_impl(zshg_index_t v, zshg_index_t r, zshg_index_t from, struct visits *visits, zshg_index_t forbidden0, zshg_index_t forbidden1)
{
	if (!r)
		return(0);

	visit2(visits, v);
	r--;

	zshg_index_t d = query_degree(v);

	for (zshg_index_t i = 0; i < d && r; i++)
	{
		zshg_index_t n = query_neighbour(v, i);

		if (v == forbidden0 && n == forbidden1 || n == forbidden0 && v == forbidden1)
			continue;

		if (visited2(visits, n, v))
			continue;

		r = dfs2_impl(n, r, v, visits, forbidden0, forbidden1);
	}

	return(r);
}

// Check if s is in a 2-set of size up to r in the graph without the edge between forbidden0 and forbidden1
static zshg_index_t set2_impl(zshg_index_t s, zshg_index_t r, zshg_index_t forbidden0, zshg_index_t forbidden1)
{
	zshg_index_t n;
	visits_t visits;

	init_visits(&visits, r);

	n = r - dfs_impl(s, r, ZSHG_INDEX_INVALID, &visits, forbidden0, forbidden1);

	if (n == r)
	{
		init_visits2(&visits);
		n = r - dfs2_impl(s, r, ZSHG_INDEX_INVALID, &visits, forbidden0, forbidden1);
	}

	destroy_visits(&visits);

	return(n);
}

// Check if s is in a 2-set of size up to r
static zshg_index_t set2(zshg_index_t s, zshg_index_t r)
{
	return(set2_impl(s, r, ZSHG_INDEX_INVALID, ZSHG_INDEX_INVALID));
}

// Check if s is in a 3-set size up to r
static zshg_index_t set3(zshg_index_t s, zshg_index_t r)
{
	zshg_index_t n;
	visits_t visits;

	init_visits(&visits, r);

	n = r - dfs_impl(s, r, ZSHG_INDEX_INVALID, &visits, ZSHG_INDEX_INVALID, ZSHG_INDEX_INVALID);

	if (n == r)
	for (zshg_index_t i = 0; i < visits.size; i++)
	{
		if (visits.map[i].index == ZSHG_INDEX_INVALID || visits.map[i].from == ZSHG_INDEX_INVALID)
			continue;

		n = set2_impl(s, r, visits.map[i].index, visits.map[i].from);

		if (n < r)
			break;
	}

	destroy_visits(&visits);

	return(n);
}

// 2-edge-connectivity Testing.
// Returns true for connected graphs.
// Returns false with probability at least p for graphs that are e-far from connectivity.
bool zshg2(double e, double p)
{
	return(zshg_impl(e, p, 2, set2));
}

// 3-edge-connectivity Testing.
// Returns true for connected graphs.
// Returns false with probability at least p for graphs that are e-far from connectivity.
bool zshg3(double e, double p)
{
	return(zshg_impl(e, p, 3, set3));
}

bool zshg2_imp(double e, double p)
{
	return(zshg_impl_imp(e, p, 1, set2));
}

bool zshg3_imp(double e, double p)
{
	return(zshg_impl_imp(e, p, 1, set3));
}