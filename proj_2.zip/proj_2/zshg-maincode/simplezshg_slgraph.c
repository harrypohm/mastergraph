// A simple program for testing connectivity. It uses slgraph.

// Philipp Klaus Krause, philipp@informatik.uni-frankfurt.de, pkk@spth.de, 2009 - 2017
// Copyright (c) 2014-2017 Philipp Klaus Krause
// Copyright (c) 2017 University of Leeds

// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "slgraph.h"

#include "zshg.h"

slgraph_t graph;

unsigned long queries;

zshg_index_t query_n(void)
{
	queries++;
	return(slgraph_nodes(&graph));
}

double query_d(void)
{
	queries++;
	return(2.0 * slgraph_edges(&graph) / slgraph_nodes(&graph));
}

zshg_index_t query_degree(zshg_index_t v)
{
	queries++;
	return(slgraph_degree(&graph, v));
}

zshg_index_t query_neighbour(zshg_index_t v, zshg_index_t i)
{
	queries++;
	return(slgraph_neighbour(&graph, v, i));
}

void usage(FILE *f)
{
	fprintf(f, "zshg_slgraph - testing connectivity in constant time for an slgraph.\n");
	fprintf(f, "Usage: zshgd [--help] [--epsilon e] [--probability p] filename\n");
	fprintf(f, "Supported epsilon range: ]0.0, 0.5[.\n");
	fprintf(f, "Supported probability range: ]0.0, 1.0[.\n");
}

int main(int argc, char *argv[])
{
	const char *filename = "";
	double epsilon = 0.1;
	double probability = 2.0 / 3.0;

	for(int i = 1; i < argc - 1; i++)
	{
		if(!strcmp("--epsilon", argv[i]))
		{
			epsilon = strtod(argv[++i], 0);
			if(epsilon <= 0.0 || epsilon >= 0.5)
			{
				fprintf(stderr, "Invalid epsilon.\n");
				return(-1);
			}
		}
		else if(!strcmp("--probability", argv[i]))
		{
			probability = strtod(argv[++i], 0);
			if(probability <= 0.0 || probability >= 1.0)
			{
				fprintf(stderr, "Invalid probability.\n");
				return(-1);
			}
		}
		else
		{
			usage(!strcmp("--help", argv[i]) ? stdout : stderr);
			return(-1);
		}
	}
	if(argc < 2 || !strncmp("--", argv[argc - 1], 2))
	{
		usage(!strcmp("--help", argv[argc - 1]) ? stdout : stderr);
		return(-1);
	}
	filename = argv[argc - 1];

	srand(clock());

	time_t t = time(0);

	if(slgraph_open(&graph, filename, true))
	{
		printf("Failed to read input graph in file %s.\n", filename);
		return(-1);
	}

	printf("Loading slgraph: %ld seconds\n", (long)(time(0) - t));

	bool maybe_connected, maybe_2_edge_connected, maybe_3_edge_connected;

	t = time(0);
	queries = 0;
	maybe_connected = zshg(epsilon, probability);
	printf("zshgd(): %ld seconds, %lu queries\n", (long)(time(0) - t), queries);

	if(maybe_connected)
		printf("The graph is considered to be connected. If it is %.9f-far from being connected, this happens with probability at most %.9f.\n", epsilon, 1.0 - probability);
	else
		printf("The graph is unconnected.\n");

	if(maybe_connected)
	{
		t = time(0);
		queries = 0;
		maybe_2_edge_connected = zshg2(epsilon, probability);
		printf("zshgd2(): %ld seconds, %lu queries\n", (long)(time(0) - t), queries);

		if(maybe_2_edge_connected)
			printf("The graph is considered to be 2-edge-connected. If it is %.9f-far from being connected, this happens with probability at most %.9f.\n", epsilon, 1.0 - probability);
		else
			printf("The graph is not 2-edge-connected.\n");
	}
	else
		maybe_2_edge_connected = false;

	if(maybe_2_edge_connected)
	{
		t = time(0);
		queries = 0;
		maybe_3_edge_connected = zshg3(epsilon, probability);
		printf("zshgd3(): %ld seconds, %lu queries\n", (long)(time(0) - t), queries);

		if(maybe_3_edge_connected)
			printf("The graph is considered to be 3-edge-connected. If it is %.9f-far from being connected, this happens with probability at most %.9f.\n", epsilon, 1.0 - probability);
		else
			printf("The graph is not 3-edge-connected.\n");
	}

	slgraph_close(&graph);

	return(0);
}

